      </div>
      <div id="wrap-footer" class="wrap-footer">
        <footer id="colophon" class="site-footer">
          <nav id="site-footer-navigation">
            <?php wp_nav_menu( array( 'theme_location' => 'footer', 'menu_id' => 'menu-footer', 'menu_class' => 'menu-inline' ) ); ?>
          </nav>
        </footer>
      </div>
    </div>
  <?php wp_footer(); ?>
  </body>
</html>